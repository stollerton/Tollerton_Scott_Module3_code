//Gets stored ID from onclick event that is stored in localstorage
function updateCheckbox(objectId) {
    var thisBox = document.getElementById(objectId);
    localStorage.setItem(objectId, thisBox.checked);
    //console.log('bang from ' + objectId);
    updateNumChecksDoneCount();
    
if(thisBox.checked)
        {
            if(thisBox.closest(".seclistitem") != null)
            {
            thisBox.closest(".seclistitem").className = "altseclistitem";
            }
        }
        else
        {
            if(thisBox.closest(".altseclistitem") != null)
            {
            thisBox.closest(".altseclistitem").className = "seclistitem";
            }
        }
}

//This is where the checkboxes get remembered, correctly
function loadCheckbox(domObject) {
    var retVal = 0;
    
    if(domObject) {
        var objectId = domObject.id;
        //console.log('finding checkstate for '+ objectId);
        if (objectId) {
            var isChecked = JSON.parse(localStorage.getItem(objectId));
            //console.log ('got check value of ' + isChecked + ' for ' + objectId);
            if(isChecked) {
                document.getElementById(objectId).checked = true;
                retVal = 1;
                 document.getElementById(objectId).closest(".seclistitem").className = "altseclistitem"
            }
        } else {
           //console.log('no checkstate found for ' + objectId);
        }
    }
    
    return retVal;
}

function updateNumChecksDoneCount() {
    var listOfBoxes = document.getElementsByTagName("input");
    var numBoxesChecked = 0;
    
    for (let i = 0; i < listOfBoxes.length; i++) {
        var currentCheckboxId = listOfBoxes[i].id;
        if (document.getElementById(listOfBoxes[i].id).checked) {
            numBoxesChecked++;
        }
    }
    
    document.getElementById("numChecksDone").innerHTML = numBoxesChecked;
}

//function loads all the checkboxes into javascript
function loadAllCheckboxes() {
    //console.log('bang from load')
    var listOfBoxes = document.getElementsByTagName("input");
    var numBoxesChecked = 0;
    //console.log("listOfBoxes has type " + typeof(listOfBoxes));
    //console.log(listOfBoxes);
    for (let i = 0; i < listOfBoxes.length; i++) {
        //console.log('myidx = ' + i);
        numBoxesChecked += loadCheckbox(listOfBoxes[i]);
    }
    document.getElementById("numChecksTotal").innerHTML = listOfBoxes.length;
    document.getElementById("numChecksDone").innerHTML = numBoxesChecked;
}